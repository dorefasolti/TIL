package com.mira.run;
import com.mira.study.ReviewCasting;
public class Run {
	public static void main(String[] args) {
	
		ReviewCasting r = new ReviewCasting();
		
		r.autoCasting();
		r.forceCasting();
	}
}
