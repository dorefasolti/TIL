package com.mira.tomorrow;

public class SecondStudy {
	public void methodA() {
		System.out.println("메소드 호출 완료!");
	}
}
