package com.mira.run;

import com.mira.study.ReviewTriple;

public class Run {
	public static void main(String[] args) {
		ReviewTriple rt = new ReviewTriple();
		rt.triple();
	}

}
