package com.mira.study;

import java.util.Scanner;

public class ReviewTriple {
	public void triple() {
//		삼항연산자 : 피연산자가 3개 => 값 3개와 연산자 1개로 이루어짐
//		조건식 : 결과값에 따라 연산을 처리하는 방식
//		(5 > 10) ? 1 : 0;
//		결과값이 참일 경우 식1을 처리
//		결과값이 거짓인 경우 식2를 처리
		
		
	}
	public void control() {
//		조건문
//		주어진 조건에 따라 다른 문장을 선택할 수 있도록 프로그래밍 하는 것
		
/*		☆ if문
	*		만약~이라면
	*		if(조건식) {
	*			수행문;
	*		}
*		
*		☆ if-else문
	*		if(조건식){ 					//if 열기
	*			수행문1;
	*		}							//if 닫기
	*		else{						//else열기
	*			수행문2;
	*		}							//else닫기
*		
*
*		☆if-else if-else문
*			if(조건식1){
*				수행문1//조건식1이 참이면 수행, 거짓이면 내려감
*			}
*			else if(조건식2){
*				수행문2//조건식2가 참이면 수행, 거짓이면 내려감
*			}
*			else if(조건식3){
*				수행문3//조건식3이 참이면 수행, 거짓이면 내려감
*			}
*			else {
*				수행문4;//위의 조건이 모두 해당하지 않는 경우 수행
*			}
*			수행문5//if-else if-else문이 끝난 후 수행
*
*
*/			
		
	}
}
