package com.mira.run;
import com.mira.study.ReviewVariable;
import com.mira.study.ReviewOperator;
public class Run {
	public static void main(String[] args) {
		
//		ReviewVariable rv = new ReviewVariable();
//		rv.variable();
		ReviewOperator ro = new ReviewOperator();
		ro.operator();
	}
}
