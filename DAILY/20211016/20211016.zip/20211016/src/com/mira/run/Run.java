package com.mira.run;
import com.mira.study.Operator;
public class Run {
	public static void main(String[] args) {
		
		Operator o = new Operator();
		
		o.arithmetic();
		o.increaseDecrease();
		o.compound();
		o.negation();
		o.comparison();
		
	}

}
