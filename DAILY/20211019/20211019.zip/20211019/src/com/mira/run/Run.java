package com.mira.run;

import com.mira.study.ReviewFor;
import com.mira.study.ReviewSwitch;

public class Run {
	public static void main(String[] args) {
	
		ReviewSwitch rs = new ReviewSwitch();
//		rs.iceCream();
//		rs.logIn();
		
		ReviewFor rf = new ReviewFor();
		rf.method1();
	}
}
